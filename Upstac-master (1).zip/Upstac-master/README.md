# Upstac
## Website for online medical consultation.



## Install:
#### MYSQL Community Server: https://dev.mysql.com/downloads/file/?id=499256
#### MYSQL WorkBench: https://dev.mysql.com/downloads/windows/installer/8.0.html
#### Node JS:https://nodejs.org/en/download/

## First-Run Commands:
 npm install -g yarn
 
 yarn install

## Deploying App
 Start Front End: yarn start
 
 Backend Start by running the UpstacApplication Class.
##### Note: Make sure MYSQL server is running and update the database in application.properties
